/* FoxHole package transactions, derived from apk-tools app_add.c.
 * Modified for FoxHole, 2026-10-28.
 * Copyright (C) 2005-2008 Natanael Copa <n@tanael.org>
 * Copyright (C) 2008-2021 Timo Teräs <timo.teras@iki.fi>
 * SPDX-License-Identifier: GPL-2.0-only
 */

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include "apk_applet.h"
#include "apk_database.h"
#include "apk_adb.h"
#include "apk_extract.h"
#include "apk_print.h"
#include "apk_solver.h"
#include "apk_trust.h"

static int foxhole_permitted(struct apk_ctx *ac)
{
	if (!ac->foxhole_explicit_root || ac->force || (ac->flags & APK_SIMULATE) || ac->db->lock_fd < 0 ||
	    apk_ctx_get_trust(ac)->allow_untrusted) return 0;
#ifndef FOXHOLE_TRANSACTION_QA
	if (geteuid() != 0) return 0;
#endif
	return 1;
}

static int foxhole_module_allowed(struct apk_dependency *module)
{
	static const char *prefixes[] = {
		"foxcore-engine-vless-flash-", "foxcore-engine-vless-ram-",
		"foxcore-engine-hysteria2-flash-", "foxcore-engine-hysteria2-ram-",
		"foxcore-engine-wireguard-flash-", "foxcore-engine-wireguard-ram-",
	};
	if (!module->name || module->op != APK_VERSION_EQUAL || module->repository_tag ||
	    !module->version || !module->version->len) return 0;
	for (int i = 0; i < (int)ARRAY_SIZE(prefixes); i++) {
		const char *suffix = module->name->name;
		size_t length = strlen(prefixes[i]);
		if (strncmp(suffix, prefixes[i], length)) continue;
		suffix += length;
		if (strlen(suffix) != 64) return 0;
		for (int j = 0; j < 64; j++)
			if (!((suffix[j] >= '0' && suffix[j] <= '9') || (suffix[j] >= 'a' && suffix[j] <= 'f'))) return 0;
		return 1;
	}
	return 0;
}

static int foxhole_parse_dep(struct apk_database *db, const char *text, struct apk_dependency *dep, int module)
{
	apk_blob_t input = APK_BLOB_STR(text);
	apk_blob_pull_dep(&input, db, dep, true);
	if (APK_BLOB_IS_NULL(input) || input.len || dep->broken || !dep->name ||
	    dep->op != APK_VERSION_EQUAL || dep->repository_tag || !dep->version || !dep->version->len) return 0;
	return module ? foxhole_module_allowed(dep) : !strcmp(dep->name->name, "foxhole-openwrt-client");
}

static int foxhole_lock_metadata(struct apk_database *db)
{
	const char *parts[] = { "lib", "apk", "db" };
	struct stat path, held;
	int dirs[3] = { -1, -1, -1 }, parent = db->root_fd, ok = 0;
	for (int i = 0; i < 3; i++) {
		dirs[i] = openat(parent, parts[i], O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
		if (dirs[i] < 0 || fstat(dirs[i], &path) || !S_ISDIR(path.st_mode) ||
		    path.st_uid != geteuid() || (path.st_mode & 0022)) goto done;
		parent = dirs[i];
	}
	if (fstatat(parent, "lock", &path, AT_SYMLINK_NOFOLLOW) || fstat(db->lock_fd, &held) ||
	    !S_ISREG(path.st_mode) || path.st_uid != geteuid() || path.st_nlink != 1 ||
	    (path.st_mode & 0022) || path.st_dev != held.st_dev || path.st_ino != held.st_ino ||
	    path.st_mode != held.st_mode || path.st_nlink != held.st_nlink) goto done;
	ok = 1;
done:
	for (int i = 2; i >= 0; i--) if (dirs[i] >= 0) close(dirs[i]);
	return ok;
}

static int foxhole_world_metadata(struct apk_database *db, const char *expected)
{
	struct stat a, b;
	struct apk_digest digest;
	char data[65536], hex[65];
	size_t total = 0;
	int etc = -1, dir = -1, world = -1, ok = 0;
	if (!expected || strlen(expected) != 64) return 0;
	etc = openat(db->root_fd, "etc", O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
	if (etc < 0 || fstat(etc, &a) || !S_ISDIR(a.st_mode) || a.st_uid != geteuid() || (a.st_mode & 0022)) goto done;
	dir = openat(etc, "apk", O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
	if (dir < 0 || fstat(dir, &a) || !S_ISDIR(a.st_mode) || a.st_uid != geteuid() || (a.st_mode & 0022)) goto done;
	if (fstatat(dir, "world", &a, AT_SYMLINK_NOFOLLOW) || !S_ISREG(a.st_mode) ||
	    a.st_uid != geteuid() || a.st_nlink != 1 || (a.st_mode & 0022) || a.st_size < 1 || a.st_size > 65536) goto done;
	world = openat(dir, "world", O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
	if (world < 0 || fstat(world, &b) || a.st_dev != b.st_dev || a.st_ino != b.st_ino ||
	    a.st_mode != b.st_mode || a.st_uid != b.st_uid || a.st_nlink != b.st_nlink || a.st_size != b.st_size) goto done;
	while (total < (size_t)a.st_size) {
		ssize_t n = read(world, data + total, a.st_size - total);
		if (n <= 0) goto done;
		total += n;
	}
	if (fstat(world, &b) || a.st_dev != b.st_dev || a.st_ino != b.st_ino || a.st_size != b.st_size ||
	    fstatat(dir, "world", &b, AT_SYMLINK_NOFOLLOW) || a.st_dev != b.st_dev || a.st_ino != b.st_ino ||
	    apk_digest_calc(&digest, APK_DIGEST_SHA256, data, total) || digest.len != 32) goto done;
	for (int i = 0; i < 32; i++) snprintf(hex + 2*i, 3, "%02x", digest.data[i]);
	if (strcmp(hex, expected)) goto done;
	ok = 1;
done:
	if (world >= 0) close(world);
	if (dir >= 0) close(dir);
	if (etc >= 0) close(etc);
	return ok;
}

static int foxhole_identity_matches(struct apk_package *pkg, const char *expected)
{
	char hex[65];
	apk_blob_t digest;
	if (!pkg || pkg->digest_alg != APK_DIGEST_SHA256 || !expected || strlen(expected) != 64) return 0;
	digest = apk_pkg_digest_blob(pkg);
	if (digest.len != 32 || !digest.ptr) return 0;
	for (int i = 0; i < 32; i++) snprintf(hex + 2*i, 3, "%02x", (unsigned char)digest.ptr[i]);
	return !strcmp(hex, expected);
}

static int foxhole_installed_identity_matches(struct apk_package *pkg, const char *expected)
{
	char hex[41];
	apk_blob_t digest;
	const char prefix[] = "sha256-160:";
	if (!pkg || !pkg->ipkg || !pkg->ipkg->sha256_160 ||
	    pkg->digest_alg != APK_DIGEST_SHA256_160 || !expected ||
	    strlen(expected) != sizeof(prefix)-1+40 || strncmp(expected, prefix, sizeof(prefix)-1)) return 0;
	digest = apk_pkg_digest_blob(pkg);
	if (digest.len != 20 || !digest.ptr) return 0;
	for (int i = 0; i < 20; i++) snprintf(hex + 2*i, 3, "%02x", (unsigned char)digest.ptr[i]);
	return !strcmp(hex, expected + sizeof(prefix)-1);
}

static int foxhole_expected_provider(struct apk_dependency *dep, const char *expected)
{
	int count = 0;
	if (!dep->name || !expected) return 0;
	apk_array_foreach(provider, dep->name->providers) {
		struct apk_package *pkg = provider->pkg;
		if (!pkg || pkg->name != dep->name || !pkg->repos || !apk_dep_is_materialized(dep, pkg)) continue;
		if (!foxhole_identity_matches(pkg, expected)) return 0;
		count++;
	}
	return count > 0;
}

struct foxhole_archive_check {
	struct apk_extract_ctx extract;
	const struct apk_dependency *target;
	const apk_blob_t *arch;
	struct apk_database *db;
	struct apk_digest identity;
	int metadata_seen, callback_error;
	uint64_t files_expected, files_seen;
};

static int foxhole_archive_stat_matches(const struct stat *a, const struct stat *b)
{
#ifdef __APPLE__
	const struct timespec *am = &a->st_mtimespec, *bm = &b->st_mtimespec;
	const struct timespec *ac = &a->st_ctimespec, *bc = &b->st_ctimespec;
#else
	const struct timespec *am = &a->st_mtim, *bm = &b->st_mtim;
	const struct timespec *ac = &a->st_ctim, *bc = &b->st_ctim;
#endif
	return a->st_dev == b->st_dev && a->st_ino == b->st_ino &&
		a->st_mode == b->st_mode && a->st_uid == b->st_uid && a->st_gid == b->st_gid &&
		a->st_nlink == b->st_nlink && a->st_size == b->st_size &&
		am->tv_sec == bm->tv_sec && am->tv_nsec == bm->tv_nsec &&
		ac->tv_sec == bc->tv_sec && ac->tv_nsec == bc->tv_nsec;
}

static int foxhole_archive_parent(const char *path, char *storage, size_t capacity, char **leaf)
{
	char *part, *next, *cursor;
	size_t length;
	int fd = -1, child;
	if (!path || path[0] != '/') return -1;
	length = strlen(path);
	if (length < 2 || length >= capacity || path[length-1] == '/') return -1;
	memcpy(storage, path, length+1);
	fd = open("/", O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
	if (fd < 0) return -1;
	part = strtok_r(storage+1, "/", &cursor);
	while (part) {
		if (!strcmp(part, ".") || !strcmp(part, "..")) break;
		next = strtok_r(NULL, "/", &cursor);
		if (!next) { *leaf = part; return fd; }
		child = openat(fd, part, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
		if (child < 0) break;
		close(fd);
		fd = child;
		part = next;
	}
	close(fd);
	return -1;
}

static int foxhole_archive_metadata(struct apk_extract_ctx *extract, struct adb_obj *pkg)
{
	struct foxhole_archive_check *check = container_of(extract, struct foxhole_archive_check, extract);
	struct adb_obj info, paths, path, files;
	apk_blob_t arch;
	int compatible = 0;
	int count;
	if (check->metadata_seen++) return -APKE_ADB_SCHEMA;
	adb_ro_obj(pkg, ADBI_PKG_PKGINFO, &info);
	arch = adb_ro_blob(&info, ADBI_PI_ARCH);
	if (check->arch) compatible = !apk_blob_compare(arch, *check->arch);
	else {
		compatible = !apk_blob_compare(arch, *check->db->noarch);
		apk_array_foreach(item, check->db->arches)
			if (!apk_blob_compare(arch, **item)) compatible = 1;
	}
	if (!arch.ptr || !arch.len || !compatible ||
	    apk_blob_compare(adb_ro_blob(&info, ADBI_PI_NAME), APK_BLOB_STR(check->target->name->name)) ||
	    apk_blob_compare(adb_ro_blob(&info, ADBI_PI_VERSION), *check->target->version)) return -APKE_ADB_SCHEMA;
	adb_ro_obj(pkg, ADBI_PKG_PATHS, &paths);
	count = adb_ra_num(&paths);
	for (int i = ADBI_FIRST; i <= count; i++) {
		adb_ro_obj(&paths, i, &path);
		adb_ro_obj(&path, ADBI_DI_FILES, &files);
		check->files_expected += adb_ra_num(&files);
		if (adb_ro_blob(&path, ADBI_DI_NAME).len) check->files_expected++;
	}
	return 0;
}

static int foxhole_archive_file(struct apk_extract_ctx *extract, const struct apk_file_info *file, struct apk_istream *stream)
{
	struct foxhole_archive_check *check = container_of(extract, struct foxhole_archive_check, extract);
	int r = 0;
	if (stream) {
		r = apk_istream_skip(stream, file->size);
		r = apk_istream_close_error(stream, r < 0 ? r : 0);
	}
	if (r) check->callback_error = r;
	else check->files_seen++;
	return r;
}

static const struct apk_extract_ops foxhole_archive_ops = {
	.v3meta = foxhole_archive_metadata,
	.file = foxhole_archive_file,
};

static int foxhole_target_archive(struct apk_ctx *ac, const struct apk_dependency *target,
		const apk_blob_t *arch, const char *expected, const char *path, struct apk_digest *identity)
{
	struct foxhole_archive_check check = { .target = target, .arch = arch, .db = ac->db };
	struct stat parent_before, parent_after, before, opened, after, named;
	char storage[PATH_MAX], again[PATH_MAX], *leaf, *again_leaf, hex[65];
	struct apk_istream *stream;
	int parent = -1, fd = -1, repeat = -1, stream_fd, result = -1;
	if ((arch && (!arch->ptr || !arch->len)) || !expected || strlen(expected) != 64 ||
	    apk_ctx_get_trust(ac)->allow_untrusted) return -1;
	parent = foxhole_archive_parent(path, storage, sizeof storage, &leaf);
	if (parent < 0 || fstat(parent, &parent_before) || !S_ISDIR(parent_before.st_mode) ||
	    parent_before.st_uid != geteuid() || (parent_before.st_mode & 0022) ||
	    fstatat(parent, leaf, &before, AT_SYMLINK_NOFOLLOW) || !S_ISREG(before.st_mode) ||
	    before.st_uid != geteuid() || before.st_nlink != 1 || (before.st_mode & 0022) ||
	    before.st_size <= 0 || before.st_size > 8*1024*1024) goto done;
	fd = openat(parent, leaf, O_RDONLY | O_NOFOLLOW | O_CLOEXEC | O_NONBLOCK);
	if (fd < 0 || fstat(fd, &opened) || !foxhole_archive_stat_matches(&before, &opened)) goto done;
	stream_fd = fcntl(fd, F_DUPFD_CLOEXEC, 3);
	if (stream_fd < 0) goto done;
	stream = apk_istream_from_fd(stream_fd);
	if (IS_ERR(stream)) goto done;
	apk_extract_init(&check.extract, ac, &foxhole_archive_ops);
	/* Identity generation preserves native signature verification; verify_identity can bypass it. */
	apk_extract_generate_identity(&check.extract, APK_DIGEST_SHA256, &check.identity);
	if (apk_extract_v3(&check.extract, stream) || check.metadata_seen != 1 || check.callback_error ||
	    check.files_seen != check.files_expected || check.identity.alg != APK_DIGEST_SHA256 || check.identity.len != 32) goto done;
	for (int i = 0; i < 32; i++) snprintf(hex+2*i, 3, "%02x", check.identity.data[i]);
	if (strcmp(hex, expected)) goto done;
	repeat = foxhole_archive_parent(path, again, sizeof again, &again_leaf);
	if (repeat < 0 || fstat(fd, &after) || fstat(repeat, &parent_after) ||
	    fstatat(repeat, again_leaf, &named, AT_SYMLINK_NOFOLLOW) ||
	    !foxhole_archive_stat_matches(&before, &after) ||
	    !foxhole_archive_stat_matches(&before, &named) ||
	    !foxhole_archive_stat_matches(&parent_before, &parent_after)) goto done;
	*identity = check.identity;
	result = 0;
done:
	if (repeat >= 0) close(repeat);
	if (fd >= 0) close(fd);
	if (parent >= 0) close(parent);
	return result;
}

static int foxhole_installed_archive_identity_matches(struct apk_package *pkg, const struct apk_digest *archive)
{
	apk_blob_t stored;
	if (!pkg || !pkg->ipkg || !pkg->ipkg->sha256_160 || pkg->digest_alg != APK_DIGEST_SHA256_160 ||
	    archive->alg != APK_DIGEST_SHA256 || archive->len != 32) return 0;
	stored = apk_pkg_digest_blob(pkg);
	/* This is the native installed-DB SHA256_160 mapping, not a stored full SHA256 claim. */
	return stored.ptr && stored.len == 20 && !memcmp(stored.ptr, archive->data, 20);
}

static int foxhole_serialized_world_matches(struct apk_database *db,
		struct apk_dependency_array *world, const char *expected)
{
	char storage[65536], hex[65];
	apk_blob_t whole = APK_BLOB_BUF(storage), remaining = whole, used;
	struct apk_digest digest;
	int count = 0;
	if (!expected || strlen(expected) != 64) return 0;
	apk_array_foreach(dep, world) {
		if (dep->layer != APK_DB_LAYER_ROOT) continue;
		if (count++) apk_blob_push_blob(&remaining, APK_BLOB_STRLIT("\n"));
		apk_blob_push_dep(&remaining, db, dep);
	}
	apk_blob_push_blob(&remaining, APK_BLOB_STRLIT("\n"));
	used = apk_blob_pushed(whole, remaining);
	if (APK_BLOB_IS_NULL(used) || apk_digest_calc(&digest, APK_DIGEST_SHA256, used.ptr, used.len) || digest.len != 32) return 0;
	for (int i = 0; i < 32; i++) snprintf(hex + 2*i, 3, "%02x", digest.data[i]);
	return !strcmp(hex, expected);
}

static int foxhole_apply_changes(void *ctx, struct apk_ctx *ac, struct apk_string_array *args)
{
	struct apk_database *db = ac->db;
	struct apk_dependency target, modules[3], module_root;
	struct apk_dependency_array *solve_world, *desired_world;
	struct apk_changeset changeset = {};
	struct apk_package *installed;
	apk_blob_t input;
	int source_fd = -1, expected_target_changes, target_roots = 0, target_changes = 0, result = -1;
	int module_count = apk_array_len(args) - 3, module_changes[3] = {0};

	if (!foxhole_permitted(ac) || module_count < 0 || module_count > 3 ||
	    !foxhole_lock_metadata(db) || !foxhole_world_metadata(db, args->item[2])) return -1;
	input = APK_BLOB_STR(args->item[0]);
	apk_blob_pull_dep(&input, db, &target, true);
	if (APK_BLOB_IS_NULL(input) || input.len || target.broken || !target.name ||
	    strcmp(target.name->name, "foxhole-openwrt-client") || target.op != APK_VERSION_EQUAL) return -1;
	for (int i = 0; i < module_count; i++) {
		input = APK_BLOB_STR(args->item[3+i]);
		apk_blob_pull_dep(&input, db, &modules[i], true);
		if (APK_BLOB_IS_NULL(input) || input.len || modules[i].broken || !foxhole_module_allowed(&modules[i]) ||
		    apk_pkg_get_installed(modules[i].name)) return -1;
		for (int j = 0; j < i; j++) if (modules[j].name == modules[i].name) return -1;
	}
	installed = apk_pkg_get_installed(target.name);
	if (!installed || !installed->version || !args->item[1][0] ||
	    apk_blob_compare(*installed->version, APK_BLOB_STR(args->item[1]))) return -1;
	expected_target_changes = apk_dep_is_materialized(&target, installed) ? 0 : 1;
	apk_array_foreach(dep, db->world) {
		if (dep->name == target.name) {
			if (dep->op != APK_DEPMASK_ANY || dep->repository_tag) return -1;
			target_roots++;
		}
		for (int i = 0; i < module_count; i++) if (dep->name == modules[i].name) return -1;
	}
	if (target_roots != 1 || db->active_layers != (1U << APK_DB_LAYER_ROOT) ||
	    !foxhole_serialized_world_matches(db, db->world, args->item[2])) return -1;
	apk_dependency_array_init(&solve_world);
	apk_dependency_array_init(&desired_world);
	apk_dependency_array_copy(&solve_world, db->world);
	apk_dependency_array_copy(&desired_world, db->world);
	apk_deps_add(&solve_world, &target);
	for (int i = 0; i < module_count; i++) {
		apk_deps_add(&solve_world, &modules[i]);
		module_root = modules[i];
		module_root.op = APK_DEPMASK_ANY;
		module_root.version = &apk_atom_null;
		apk_deps_add(&desired_world, &module_root);
	}
	apk_change_array_init(&changeset.changes);
	if (apk_solver_solve(db, 0, solve_world, &changeset) != 0) goto done;
	apk_array_foreach(change, changeset.changes) {
		if (change->old_pkg == change->new_pkg && !change->reinstall &&
		    change->old_repository_tag == change->new_repository_tag) continue;
		if (change->old_pkg == installed && change->new_pkg &&
		    change->new_pkg->name == target.name && apk_dep_is_materialized(&target, change->new_pkg)) {
			target_changes++;
		} else {
			int matched = 0;
			for (int i = 0; i < module_count; i++) {
				if (!change->old_pkg && change->new_pkg && change->new_pkg->name == modules[i].name &&
				    apk_dep_is_materialized(&modules[i], change->new_pkg)) {
					module_changes[i]++;
					matched = 1;
					break;
				}
			}
			if (!matched) goto done;
		}
	}
	for (int i = 0; i < module_count; i++) if (module_changes[i] != 1) goto done;
	if (target_changes != expected_target_changes || !foxhole_lock_metadata(db) ||
	    !foxhole_world_metadata(db, args->item[2])) goto done;
	if (!target_changes && !module_count) { result = 0; goto done; }
	source_fd = openat(db->root_fd, "etc/apk/world", O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
	if (source_fd < 0) goto done;
	db->foxhole_world_stream = apk_ostream_to_file_safe(db->root_fd, "etc/apk/world", 0644);
	if (IS_ERR(db->foxhole_world_stream)) { db->foxhole_world_stream = NULL; goto done; }
	if (apk_foxhole_copy_world_attrs(db->foxhole_world_stream, source_fd, args->item[2]) ||
	    !foxhole_lock_metadata(db) || !foxhole_world_metadata(db, args->item[2])) goto done;
	result = apk_solver_commit_changeset(db, &changeset, desired_world);
done:
	if (source_fd >= 0) close(source_fd);
	if (db->foxhole_world_stream) {
		apk_ostream_cancel(db->foxhole_world_stream, -ECANCELED);
		apk_ostream_close(db->foxhole_world_stream);
		db->foxhole_world_stream = NULL;
	}
	apk_change_array_free(&changeset.changes);
	apk_dependency_array_free(&desired_world);
	apk_dependency_array_free(&solve_world);
	return result;
}

static void foxhole_world_del(struct apk_dependency_array **pworld, struct apk_name *name)
{
	struct apk_dependency_array *world = *pworld;
	size_t count = apk_array_len(world);
	for (size_t i = 0; i < count; i++) {
		if (world->item[i].name != name) continue;
		/* The approved world hash binds surviving entry order. */
		memmove(&world->item[i], &world->item[i+1], (count-i-1)*sizeof(world->item[0]));
		apk_array_truncate(*pworld, count-1);
		return;
	}
}

static int foxhole_recover_changes(void *ctx, struct apk_ctx *ac, struct apk_string_array *args)
{
	struct apk_database *db = ac->db;
	struct apk_dependency target, modules[3], conflict;
	struct apk_dependency_array *solve_world, *desired_world;
	struct apk_changeset changeset = {};
	struct apk_package *installed, *installed_modules[3] = {0};
	apk_blob_t input;
	int source_fd = -1, expected_target_changes, target_roots = 0, target_changes = 0, result = -1;
	int module_count = apk_array_len(args) - 4, module_roots[3] = {0}, module_changes[3] = {0}, total_module_changes = 0;

	if (!foxhole_permitted(ac) || module_count < 0 || module_count > 3 ||
	    !foxhole_lock_metadata(db) || !foxhole_world_metadata(db, args->item[2])) return -1;
	input = APK_BLOB_STR(args->item[0]);
	apk_blob_pull_dep(&input, db, &target, true);
	if (APK_BLOB_IS_NULL(input) || input.len || target.broken || !target.name ||
	    strcmp(target.name->name, "foxhole-openwrt-client") || target.op != APK_VERSION_EQUAL) return -1;
	for (int i = 0; i < module_count; i++) {
		input = APK_BLOB_STR(args->item[4+i]);
		apk_blob_pull_dep(&input, db, &modules[i], true);
		if (APK_BLOB_IS_NULL(input) || input.len || modules[i].broken || !foxhole_module_allowed(&modules[i])) return -1;
		for (int j = 0; j < i; j++) if (modules[j].name == modules[i].name) return -1;
		installed_modules[i] = apk_pkg_get_installed(modules[i].name);
		if (installed_modules[i] && !apk_dep_is_materialized(&modules[i], installed_modules[i])) return -1;
	}
	installed = apk_pkg_get_installed(target.name);
	if (!installed || !installed->version || !args->item[1][0] ||
	    apk_blob_compare(*installed->version, APK_BLOB_STR(args->item[1]))) return -1;
	expected_target_changes = apk_dep_is_materialized(&target, installed) ? 0 : 1;
	apk_array_foreach(dep, db->world) {
		if (dep->name == target.name) {
			if (dep->op != APK_DEPMASK_ANY || dep->repository_tag) return -1;
			target_roots++;
		}
		for (int i = 0; i < module_count; i++) if (dep->name == modules[i].name) {
			if (dep->op != APK_DEPMASK_ANY || dep->repository_tag) return -1;
			module_roots[i]++;
		}
	}
	if (target_roots != 1 || db->active_layers != (1U << APK_DB_LAYER_ROOT)) return -1;
	for (int i = 0; i < module_count; i++)
		if (module_roots[i] > 1) return -1;
	apk_dependency_array_init(&solve_world);
	apk_dependency_array_init(&desired_world);
	apk_dependency_array_copy(&solve_world, db->world);
	apk_dependency_array_copy(&desired_world, db->world);
	apk_deps_add(&solve_world, &target);
	for (int i = 0; i < module_count; i++) {
		apk_deps_del(&solve_world, modules[i].name);
		conflict = modules[i];
		conflict.op = APK_DEPMASK_ANY | APK_VERSION_CONFLICT;
		conflict.version = &apk_atom_null;
		apk_deps_add(&solve_world, &conflict);
		foxhole_world_del(&desired_world, modules[i].name);
	}
	apk_change_array_init(&changeset.changes);
	if (!foxhole_serialized_world_matches(db, desired_world, args->item[3]) ||
	    apk_solver_solve(db, 0, solve_world, &changeset) != 0) goto done;
	apk_array_foreach(change, changeset.changes) {
		if (change->old_pkg == change->new_pkg && !change->reinstall &&
		    change->old_repository_tag == change->new_repository_tag) continue;
		if (change->old_pkg == installed && change->new_pkg &&
		    change->new_pkg->name == target.name && apk_dep_is_materialized(&target, change->new_pkg)) {
			target_changes++;
		} else {
			int matched = 0;
			for (int i = 0; i < module_count; i++) {
				if (installed_modules[i] && change->old_pkg == installed_modules[i] && !change->new_pkg) {
					module_changes[i]++;
					total_module_changes++;
					matched = 1;
					break;
				}
			}
			if (!matched) goto done;
		}
	}
	for (int i = 0; i < module_count; i++)
		if (module_changes[i] != (installed_modules[i] ? 1 : 0)) goto done;
	if (target_changes != expected_target_changes || !foxhole_lock_metadata(db) ||
	    !foxhole_world_metadata(db, args->item[2])) goto done;
	if (!target_changes && !total_module_changes &&
	    foxhole_serialized_world_matches(db, desired_world, args->item[2])) { result = 0; goto done; }
	source_fd = openat(db->root_fd, "etc/apk/world", O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
	if (source_fd < 0) goto done;
	db->foxhole_world_stream = apk_ostream_to_file_safe(db->root_fd, "etc/apk/world", 0644);
	if (IS_ERR(db->foxhole_world_stream)) { db->foxhole_world_stream = NULL; goto done; }
	if (apk_foxhole_copy_world_attrs(db->foxhole_world_stream, source_fd, args->item[2]) ||
	    !foxhole_lock_metadata(db) || !foxhole_world_metadata(db, args->item[2])) goto done;
	result = apk_solver_commit_changeset(db, &changeset, desired_world);
done:
	if (source_fd >= 0) close(source_fd);
	if (db->foxhole_world_stream) {
		apk_ostream_cancel(db->foxhole_world_stream, -ECANCELED);
		apk_ostream_close(db->foxhole_world_stream);
		db->foxhole_world_stream = NULL;
	}
	apk_change_array_free(&changeset.changes);
	apk_dependency_array_free(&desired_world);
	apk_dependency_array_free(&solve_world);
	return result;
}


static const apk_blob_t *foxhole_provider_arch(struct apk_dependency *dep)
{
	apk_array_foreach(provider, dep->name->providers) {
		struct apk_package *pkg = provider->pkg;
		if (pkg && pkg->name == dep->name && pkg->repos && apk_dep_is_materialized(dep, pkg)) return pkg->arch;
	}
	return NULL;
}

static int foxhole_cas_matches_archive(const char *expected, const struct apk_digest *archive)
{
	char text[52] = "sha256-160:";
	if (!expected || strlen(expected) != 51 || archive->alg != APK_DIGEST_SHA256 || archive->len != 32) return 0;
	for (int i = 0; i < 20; i++) snprintf(text+11+2*i, 3, "%02x", archive->data[i]);
	return !strcmp(text, expected);
}

static int foxhole_apply(void *ctx, struct apk_ctx *ac, struct apk_string_array *args)
{
	struct apk_database *db = ac->db;
	struct apk_dependency target, module;
	struct apk_package *installed;
	struct apk_digest identity;
	struct apk_string_array *forward;
	const apk_blob_t *arch;
	int count = apk_array_len(args), same, result;
	if (!foxhole_permitted(ac) || count < 6 || count > 15 || (count-6)%3 ||
	    !foxhole_parse_dep(db, args->item[0], &target, 0)) return -EPERM;
	installed = apk_pkg_get_installed(target.name);
	if (!installed || !installed->version || apk_blob_compare(*installed->version, APK_BLOB_STR(args->item[1])) ||
	    !foxhole_installed_identity_matches(installed, args->item[3])) return -ESTALE;
	same = apk_dep_is_materialized(&target, installed);
	if (!same && !foxhole_expected_provider(&target, args->item[4])) return -ESTALE;
	arch = same ? installed->arch : foxhole_provider_arch(&target);
	if (!arch || foxhole_target_archive(ac, &target, arch, args->item[4], args->item[5], &identity) ||
	    (same && !foxhole_installed_archive_identity_matches(installed, &identity))) return -ESTALE;
	for (int i = 6; i < count; i += 3) {
		if (!foxhole_parse_dep(db, args->item[i], &module, 1) || apk_pkg_get_installed(module.name) ||
		    !foxhole_expected_provider(&module, args->item[i+1])) return -ESTALE;
		arch = foxhole_provider_arch(&module);
		if (!arch || foxhole_target_archive(ac, &module, arch, args->item[i+1], args->item[i+2], &identity)) return -ESTALE;
	}
	apk_string_array_init(&forward);
	apk_string_array_add(&forward, args->item[0]);
	apk_string_array_add(&forward, args->item[1]);
	apk_string_array_add(&forward, args->item[2]);
	for (int i = 6; i < count; i += 3) apk_string_array_add(&forward, args->item[i]);
	result = foxhole_apply_changes(ctx, ac, forward);
	apk_string_array_free(&forward);
	return result;
}

static int foxhole_recover(void *ctx, struct apk_ctx *ac, struct apk_string_array *args)
{
	struct apk_database *db = ac->db;
	struct apk_dependency old, new, module;
	struct apk_package *installed, *added;
	struct apk_digest old_identity, new_identity, module_identity;
	struct apk_string_array *forward;
	int count = apk_array_len(args), current_old, current_new, result;
	if (!foxhole_permitted(ac) || count < 10 || count > 19 || (count-10)%3 ||
	    !foxhole_parse_dep(db, args->item[0], &old, 0) || !foxhole_parse_dep(db, args->item[1], &new, 0)) return -EPERM;
	installed = apk_pkg_get_installed(old.name);
	if (!installed || !installed->version ||
	    foxhole_target_archive(ac, &old, installed->arch, args->item[6], args->item[7], &old_identity) ||
	    foxhole_target_archive(ac, &new, installed->arch, args->item[8], args->item[9], &new_identity) ||
	    !foxhole_cas_matches_archive(args->item[4], &old_identity) ||
	    !foxhole_cas_matches_archive(args->item[5], &new_identity)) return -ESTALE;
	if (!apk_blob_compare(*old.version, *new.version) && apk_digest_cmp(&old_identity, &new_identity)) return -ESTALE;
	current_old = apk_dep_is_materialized(&old, installed) && foxhole_installed_identity_matches(installed, args->item[4]);
	current_new = apk_dep_is_materialized(&new, installed) && foxhole_installed_identity_matches(installed, args->item[5]);
	if (!current_old && !current_new) return -ESTALE;
	if (!current_old && !foxhole_expected_provider(&old, args->item[6])) return -ESTALE;
	for (int i = 10; i < count; i += 3) {
		if (!foxhole_parse_dep(db, args->item[i], &module, 1)) return -ESTALE;
		added = apk_pkg_get_installed(module.name);
		if (added && !apk_dep_is_materialized(&module, added)) return -ESTALE;
		if (foxhole_target_archive(ac, &module, added ? added->arch : NULL,
		    args->item[i+1], args->item[i+2], &module_identity) ||
		    (added && !foxhole_installed_archive_identity_matches(added, &module_identity))) return -ESTALE;
	}
	apk_string_array_init(&forward);
	apk_string_array_add(&forward, args->item[0]);
	apk_string_array_add(&forward, strchr(args->item[current_old ? 0 : 1], '=')+1);
	apk_string_array_add(&forward, args->item[2]);
	apk_string_array_add(&forward, args->item[3]);
	for (int i = 10; i < count; i += 3) apk_string_array_add(&forward, args->item[i]);
	result = foxhole_recover_changes(ctx, ac, forward);
	apk_string_array_free(&forward);
	return result;
}

static struct apk_applet foxhole_apply_applet = {
	.name = "foxhole-apply",
	.open_flags = APK_OPENF_WRITE,
	.optgroup_commit = 1,
	.main = foxhole_apply,
};
APK_DEFINE_APPLET(foxhole_apply_applet);
static struct apk_applet foxhole_recover_applet = {
	.name = "foxhole-recover",
	.open_flags = APK_OPENF_WRITE,
	.optgroup_commit = 1,
	.main = foxhole_recover,
};
APK_DEFINE_APPLET(foxhole_recover_applet);
